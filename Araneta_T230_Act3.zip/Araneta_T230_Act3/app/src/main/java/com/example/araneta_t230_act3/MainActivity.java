package com.example.araneta_t230_act3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button toBin, toHex, toOct;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        toBin = findViewById(R.id.toBinbtn);
        toBin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toBin();
            }
        });

        toHex = findViewById(R.id.toHexbtn);
        toHex.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toHex();
            }
        });

        toOct = findViewById(R.id.toOctbtn);
        toOct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toOct();
            }
        });
    }

    public void toBin(){
        Intent goToBin = new Intent(this, com.example.araneta_t230_act3.Bin.class);
        startActivity(goToBin);
    }

    public void toHex(){
        Intent goToHex = new Intent(this, com.example.araneta_t230_act3.Hex.class);
        startActivity(goToHex);
    }

    public void toOct(){
        Intent goToOct = new Intent(this, Oct.class);
        startActivity(goToOct);
    }

    public void toMenu(View view) {
    }
}