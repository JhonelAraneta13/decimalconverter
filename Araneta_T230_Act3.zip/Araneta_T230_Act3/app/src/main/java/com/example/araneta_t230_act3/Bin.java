package com.example.araneta_t230_act3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class Bin extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bin);
    }

    public void toBinary(View view){
        TextView binaryResult = findViewById(R.id.result);
        EditText decimalNum = findViewById(R.id.hexadecimal);
        int decimal = Integer.parseInt(decimalNum.getText().toString());

        int binary[] = new int[40];
        int index = 0;
        String result = "";

        while(decimal > 0){
            binary[index++] = decimal%2;
            decimal = decimal/2;
        }

        for (int i = index -1; i >= 0; i--) {
            result = result + Integer.toString(binary[i]);
        }
        binaryResult.setText(result);
    }
}