package com.example.araneta_t230_act3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class Hex extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hex);
    }

    public void toHex(View view){

        TextView result = findViewById(R.id.result);
        EditText dec = findViewById(R.id.hexadecimal);

        int decimal = Integer.parseInt(dec.getText().toString());
        int rem;
        String hex="";
        char hexchars[]={'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};

        while(decimal>0)
        {
            rem=decimal%16;
            hex=hexchars[rem]+hex;
            decimal=decimal/16;
        }

        result.setText(hex);
    }
}